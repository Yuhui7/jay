#ifndef _DList_H_
#define _DList_H_

typedef struct DNode {
	int data;
	struct DNode* prior, * next;
}DNode, * DLinkList;

void InitDLinkList(DLinkList L);
void DisplayList(DLinkList L);
void InserDList(DLinkList L);
void DeleteDList(DLinkList L);


#endif